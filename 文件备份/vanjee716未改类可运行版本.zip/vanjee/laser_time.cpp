#include "laser_time.h"
// 空实现，全部用内联